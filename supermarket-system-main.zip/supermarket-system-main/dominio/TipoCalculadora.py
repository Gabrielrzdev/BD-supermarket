from enum import Enum

class TipoCalculadora(Enum):
    JUROS_SIMPLES = 'JUROS_SIMPLES'
    JUROS_COMPOSTOS = 'JUROS_COMPOSTOS'
