from enum import Enum

class Operadora(Enum):
    VISA = 1
    MASTERCARD = 2
    AMERICAN = 3
    DINNERS = 4
