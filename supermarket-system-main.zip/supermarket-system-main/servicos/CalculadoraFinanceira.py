#interface

def calcularMontante(montante_inicial, periodoMeses, jurosAoMes)