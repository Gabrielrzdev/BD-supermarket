class IJuros:

  def consultarTaxaJuros():
    pass
  